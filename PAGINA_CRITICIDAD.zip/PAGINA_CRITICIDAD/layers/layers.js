var wms_layers = [];


        var lyr_SATELLITE_0 = new ol.layer.Tile({
            'title': 'SATELLITE',
            'type': 'base',
            'opacity': 1.000000,
            
            
            source: new ol.source.XYZ({
    attributions: ' ',
                url: 'http://www.google.cn/maps/vt?lyrs=s@189&gl=cn&x={x}&y={y}&z={z}'
            })
        });
var format_MGN_DPTO_POLITICO_1 = new ol.format.GeoJSON();
var features_MGN_DPTO_POLITICO_1 = format_MGN_DPTO_POLITICO_1.readFeatures(json_MGN_DPTO_POLITICO_1, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_MGN_DPTO_POLITICO_1 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_MGN_DPTO_POLITICO_1.addFeatures(features_MGN_DPTO_POLITICO_1);
var lyr_MGN_DPTO_POLITICO_1 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_MGN_DPTO_POLITICO_1, 
                style: style_MGN_DPTO_POLITICO_1,
                interactive: true,
                title: '<img src="styles/legend/MGN_DPTO_POLITICO_1.png" /> MGN_DPTO_POLITICO'
            });
var lyr_CALOR_TOTAL_4CTE1_2 = new ol.layer.Image({
                            opacity: 1,
                            title: "CALOR_TOTAL_4CTE1",
                            
                            
                            source: new ol.source.ImageStatic({
                               url: "./layers/CALOR_TOTAL_4CTE1_2.png",
    attributions: ' ',
                                projection: 'EPSG:3857',
                                alwaysInRange: true,
                                imageExtent: [-9263127.063866, -499360.111768, -7911644.015866, 1197111.655181]
                            })
                        });
var lyr_CALOR_VEGETACIN1_3 = new ol.layer.Image({
                            opacity: 1,
                            title: "CALOR_VEGETACIÓN1",
                            
                            
                            source: new ol.source.ImageStatic({
                               url: "./layers/CALOR_VEGETACIN1_3.png",
    attributions: ' ',
                                projection: 'EPSG:3857',
                                alwaysInRange: true,
                                imageExtent: [-9262667.425695, -499340.738045, -7911771.661340, 1181769.031081]
                            })
                        });
var lyr_CALOR_Criticidad_4 = new ol.layer.Image({
                            opacity: 1,
                            title: "CALOR_Criticidad",
                            
                            
                            source: new ol.source.ImageStatic({
                               url: "./layers/CALOR_Criticidad_4.png",
    attributions: ' ',
                                projection: 'EPSG:3857',
                                alwaysInRange: true,
                                imageExtent: [-8674987.449701, 68756.117745, -7889119.317515, 1275652.919649]
                            })
                        });
var format_Linea_STN_5 = new ol.format.GeoJSON();
var features_Linea_STN_5 = format_Linea_STN_5.readFeatures(json_Linea_STN_5, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_Linea_STN_5 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_Linea_STN_5.addFeatures(features_Linea_STN_5);
var lyr_Linea_STN_5 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_Linea_STN_5, 
                style: style_Linea_STN_5,
                interactive: true,
                title: '<img src="styles/legend/Linea_STN_5.png" /> Linea_STN'
            });
var format_4CTE_CRITICIDAD_GEAMcopiar_6 = new ol.format.GeoJSON();
var features_4CTE_CRITICIDAD_GEAMcopiar_6 = format_4CTE_CRITICIDAD_GEAMcopiar_6.readFeatures(json_4CTE_CRITICIDAD_GEAMcopiar_6, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_4CTE_CRITICIDAD_GEAMcopiar_6 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_4CTE_CRITICIDAD_GEAMcopiar_6.addFeatures(features_4CTE_CRITICIDAD_GEAMcopiar_6);
var lyr_4CTE_CRITICIDAD_GEAMcopiar_6 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_4CTE_CRITICIDAD_GEAMcopiar_6, 
                style: style_4CTE_CRITICIDAD_GEAMcopiar_6,
                interactive: true,
    title: '4CTE_CRITICIDAD_GEAM copiar<br />\
    <img src="styles/legend/4CTE_CRITICIDAD_GEAMcopiar_6_0.png" /> Alto<br />\
    <img src="styles/legend/4CTE_CRITICIDAD_GEAMcopiar_6_1.png" /> Bajo<br />\
    <img src="styles/legend/4CTE_CRITICIDAD_GEAMcopiar_6_2.png" /> Medio<br />\
    <img src="styles/legend/4CTE_CRITICIDAD_GEAMcopiar_6_3.png" /> <br />'
        });
var format_4CTE_CRITICIDAD_GEAM_7 = new ol.format.GeoJSON();
var features_4CTE_CRITICIDAD_GEAM_7 = format_4CTE_CRITICIDAD_GEAM_7.readFeatures(json_4CTE_CRITICIDAD_GEAM_7, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_4CTE_CRITICIDAD_GEAM_7 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_4CTE_CRITICIDAD_GEAM_7.addFeatures(features_4CTE_CRITICIDAD_GEAM_7);
var lyr_4CTE_CRITICIDAD_GEAM_7 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_4CTE_CRITICIDAD_GEAM_7, 
                style: style_4CTE_CRITICIDAD_GEAM_7,
                interactive: true,
                title: '<img src="styles/legend/4CTE_CRITICIDAD_GEAM_7.png" /> 4CTE_CRITICIDAD_GEAM'
            });

lyr_SATELLITE_0.setVisible(true);lyr_MGN_DPTO_POLITICO_1.setVisible(true);lyr_CALOR_TOTAL_4CTE1_2.setVisible(true);lyr_CALOR_VEGETACIN1_3.setVisible(true);lyr_CALOR_Criticidad_4.setVisible(true);lyr_Linea_STN_5.setVisible(true);lyr_4CTE_CRITICIDAD_GEAMcopiar_6.setVisible(true);lyr_4CTE_CRITICIDAD_GEAM_7.setVisible(true);
var layersList = [lyr_SATELLITE_0,lyr_MGN_DPTO_POLITICO_1,lyr_CALOR_TOTAL_4CTE1_2,lyr_CALOR_VEGETACIN1_3,lyr_CALOR_Criticidad_4,lyr_Linea_STN_5,lyr_4CTE_CRITICIDAD_GEAMcopiar_6,lyr_4CTE_CRITICIDAD_GEAM_7];
lyr_MGN_DPTO_POLITICO_1.set('fieldAliases', {'OBJECTID': 'OBJECTID', 'DPTO_CCDGO': 'DPTO_CCDGO', 'DPTO_CNMBR': 'DPTO_CNMBR', 'DPTO_NACRC': 'DPTO_NACRC', 'DPTO_CACTO': 'DPTO_CACTO', 'DPTO_NANO': 'DPTO_NANO', 'Shape_Leng': 'Shape_Leng', 'Shape_Area': 'Shape_Area', });
lyr_Linea_STN_5.set('fieldAliases', {'OBJECTID_1': 'OBJECTID_1', 'Tension': 'Tension', 'Nombre_Lar': 'Nombre_Lar', 'Longitud': 'Longitud', 'Observacio': 'Observacio', 'ID_Linea': 'ID_Linea', 'Equipo': 'Equipo', 'Ubicacion_': 'Ubicacion_', 'Fecha_Obse': 'Fecha_Obse', 'Nombre_Cir': 'Nombre_Cir', 'Shape_Leng': 'Shape_Leng', 'Estado_Amb': 'Estado_Amb', 'Expediente': 'Expediente', 'Num_Ciruit': 'Num_Ciruit', 'AnchoSer': 'AnchoSer', });
lyr_4CTE_CRITICIDAD_GEAMcopiar_6.set('fieldAliases', {'Aviso': 'Aviso', 'Clase_de_a': 'Clase_de_a', 'Área_de_e': 'Área_de_e', 'Ubicac_té': 'Ubicac_té', 'Denominaci': 'Denominaci', 'TextoCódP': 'TextoCódP', 'Grupo_cód': 'Grupo_cód', 'CANT_AVISO': 'CANT_AVISO', 'EMPRESA': 'EMPRESA', 'RESPONSABL': 'RESPONSABL', 'ESTADO_GES': 'ESTADO_GES', 'Descripci': 'Descripci', 'Orden': 'Orden', 'Prioridad': 'Prioridad', 'Fecha_de_a': 'Fecha_de_a', 'Inicio_des': 'Inicio_des', 'Fin_desead': 'Fin_desead', 'Status_usu': 'Status_usu', 'Status_sis': 'Status_sis', 'Calificaci': 'Calificaci', 'Peso': 'Peso', 'Califica_1': 'Califica_1', 'Criterio__': 'Criterio__', 'Peso_1': 'Peso_1', 'Califica_2': 'Califica_2', 'Criterio_1': 'Criterio_1', 'Peso_12': 'Peso_12', 'Califica_3': 'Califica_3', 'Criterio': 'Criterio', 'Peso_12_13': 'Peso_12_13', 'Califica_4': 'Califica_4', 'Criterio_2': 'Criterio_2', 'SUMA': 'SUMA', 'NORTE_MBOG': 'NORTE_MBOG', 'ESTE_MBOG': 'ESTE_MBOG', 'LONGITUD': 'LONGITUD', 'LATITUD': 'LATITUD', });
lyr_4CTE_CRITICIDAD_GEAM_7.set('fieldAliases', {'Aviso': 'Aviso', 'Clase_de_a': 'Clase_de_a', 'Área_de_e': 'Área_de_e', 'Ubicac_té': 'Ubicac_té', 'Denominaci': 'Denominaci', 'TextoCódP': 'TextoCódP', 'Grupo_cód': 'Grupo_cód', 'CANT_AVISO': 'CANT_AVISO', 'EMPRESA': 'EMPRESA', 'RESPONSABL': 'RESPONSABL', 'ESTADO_GES': 'ESTADO_GES', 'Descripci': 'Descripci', 'Orden': 'Orden', 'Prioridad': 'Prioridad', 'Fecha_de_a': 'Fecha_de_a', 'Inicio_des': 'Inicio_des', 'Fin_desead': 'Fin_desead', 'Status_usu': 'Status_usu', 'Status_sis': 'Status_sis', 'Calificaci': 'Calificaci', 'Peso': 'Peso', 'Califica_1': 'Califica_1', 'Criterio__': 'Criterio__', 'Peso_1': 'Peso_1', 'Califica_2': 'Califica_2', 'Criterio_1': 'Criterio_1', 'Peso_12': 'Peso_12', 'Califica_3': 'Califica_3', 'Criterio': 'Criterio', 'Peso_12_13': 'Peso_12_13', 'Califica_4': 'Califica_4', 'Criterio_2': 'Criterio_2', 'SUMA': 'SUMA', 'NORTE_MBOG': 'NORTE_MBOG', 'ESTE_MBOG': 'ESTE_MBOG', 'LONGITUD': 'LONGITUD', 'LATITUD': 'LATITUD', });
lyr_MGN_DPTO_POLITICO_1.set('fieldImages', {'OBJECTID': 'TextEdit', 'DPTO_CCDGO': 'TextEdit', 'DPTO_CNMBR': 'TextEdit', 'DPTO_NACRC': 'Range', 'DPTO_CACTO': 'TextEdit', 'DPTO_NANO': 'Range', 'Shape_Leng': 'TextEdit', 'Shape_Area': 'TextEdit', });
lyr_Linea_STN_5.set('fieldImages', {'OBJECTID_1': 'TextEdit', 'Tension': 'TextEdit', 'Nombre_Lar': 'TextEdit', 'Longitud': 'TextEdit', 'Observacio': 'TextEdit', 'ID_Linea': 'TextEdit', 'Equipo': 'TextEdit', 'Ubicacion_': 'TextEdit', 'Fecha_Obse': 'DateTime', 'Nombre_Cir': 'TextEdit', 'Shape_Leng': 'TextEdit', 'Estado_Amb': 'TextEdit', 'Expediente': 'TextEdit', 'Num_Ciruit': 'Range', 'AnchoSer': 'Range', });
lyr_4CTE_CRITICIDAD_GEAMcopiar_6.set('fieldImages', {'Aviso': 'TextEdit', 'Clase_de_a': 'TextEdit', 'Área_de_e': 'TextEdit', 'Ubicac_té': 'TextEdit', 'Denominaci': 'TextEdit', 'TextoCódP': 'TextEdit', 'Grupo_cód': 'TextEdit', 'CANT_AVISO': 'TextEdit', 'EMPRESA': 'TextEdit', 'RESPONSABL': 'TextEdit', 'ESTADO_GES': 'TextEdit', 'Descripci': 'TextEdit', 'Orden': 'TextEdit', 'Prioridad': 'TextEdit', 'Fecha_de_a': 'DateTime', 'Inicio_des': 'DateTime', 'Fin_desead': 'DateTime', 'Status_usu': 'TextEdit', 'Status_sis': 'TextEdit', 'Calificaci': 'TextEdit', 'Peso': 'TextEdit', 'Califica_1': 'TextEdit', 'Criterio__': 'TextEdit', 'Peso_1': 'TextEdit', 'Califica_2': 'TextEdit', 'Criterio_1': 'TextEdit', 'Peso_12': 'TextEdit', 'Califica_3': 'TextEdit', 'Criterio': 'TextEdit', 'Peso_12_13': 'TextEdit', 'Califica_4': 'TextEdit', 'Criterio_2': 'TextEdit', 'SUMA': 'TextEdit', 'NORTE_MBOG': 'TextEdit', 'ESTE_MBOG': 'TextEdit', 'LONGITUD': 'TextEdit', 'LATITUD': 'TextEdit', });
lyr_4CTE_CRITICIDAD_GEAM_7.set('fieldImages', {'Aviso': '', 'Clase_de_a': '', 'Área_de_e': '', 'Ubicac_té': '', 'Denominaci': '', 'TextoCódP': '', 'Grupo_cód': '', 'CANT_AVISO': '', 'EMPRESA': '', 'RESPONSABL': '', 'ESTADO_GES': '', 'Descripci': '', 'Orden': '', 'Prioridad': '', 'Fecha_de_a': '', 'Inicio_des': '', 'Fin_desead': '', 'Status_usu': '', 'Status_sis': '', 'Calificaci': '', 'Peso': '', 'Califica_1': '', 'Criterio__': '', 'Peso_1': '', 'Califica_2': '', 'Criterio_1': '', 'Peso_12': '', 'Califica_3': '', 'Criterio': '', 'Peso_12_13': '', 'Califica_4': '', 'Criterio_2': '', 'SUMA': '', 'NORTE_MBOG': '', 'ESTE_MBOG': '', 'LONGITUD': '', 'LATITUD': '', });
lyr_MGN_DPTO_POLITICO_1.set('fieldLabels', {'OBJECTID': 'no label', 'DPTO_CCDGO': 'no label', 'DPTO_CNMBR': 'no label', 'DPTO_NACRC': 'no label', 'DPTO_CACTO': 'no label', 'DPTO_NANO': 'no label', 'Shape_Leng': 'no label', 'Shape_Area': 'no label', });
lyr_Linea_STN_5.set('fieldLabels', {'OBJECTID_1': 'no label', 'Tension': 'no label', 'Nombre_Lar': 'inline label', 'Longitud': 'no label', 'Observacio': 'no label', 'ID_Linea': 'no label', 'Equipo': 'no label', 'Ubicacion_': 'no label', 'Fecha_Obse': 'no label', 'Nombre_Cir': 'no label', 'Shape_Leng': 'no label', 'Estado_Amb': 'no label', 'Expediente': 'no label', 'Num_Ciruit': 'no label', 'AnchoSer': 'no label', });
lyr_4CTE_CRITICIDAD_GEAMcopiar_6.set('fieldLabels', {'Aviso': 'no label', 'Clase_de_a': 'no label', 'Área_de_e': 'no label', 'Ubicac_té': 'no label', 'Denominaci': 'no label', 'TextoCódP': 'no label', 'Grupo_cód': 'no label', 'CANT_AVISO': 'no label', 'EMPRESA': 'no label', 'RESPONSABL': 'no label', 'ESTADO_GES': 'no label', 'Descripci': 'no label', 'Orden': 'no label', 'Prioridad': 'no label', 'Fecha_de_a': 'no label', 'Inicio_des': 'no label', 'Fin_desead': 'no label', 'Status_usu': 'no label', 'Status_sis': 'no label', 'Calificaci': 'no label', 'Peso': 'no label', 'Califica_1': 'no label', 'Criterio__': 'no label', 'Peso_1': 'no label', 'Califica_2': 'no label', 'Criterio_1': 'no label', 'Peso_12': 'no label', 'Califica_3': 'no label', 'Criterio': 'no label', 'Peso_12_13': 'no label', 'Califica_4': 'header label', 'Criterio_2': 'no label', 'SUMA': 'no label', 'NORTE_MBOG': 'no label', 'ESTE_MBOG': 'no label', 'LONGITUD': 'no label', 'LATITUD': 'no label', });
lyr_4CTE_CRITICIDAD_GEAM_7.set('fieldLabels', {'Aviso': 'header label', 'Clase_de_a': 'no label', 'Área_de_e': 'no label', 'Ubicac_té': 'no label', 'Denominaci': 'no label', 'TextoCódP': 'no label', 'Grupo_cód': 'no label', 'CANT_AVISO': 'no label', 'EMPRESA': 'no label', 'RESPONSABL': 'no label', 'ESTADO_GES': 'no label', 'Descripci': 'no label', 'Orden': 'no label', 'Prioridad': 'no label', 'Fecha_de_a': 'no label', 'Inicio_des': 'no label', 'Fin_desead': 'no label', 'Status_usu': 'no label', 'Status_sis': 'no label', 'Calificaci': 'no label', 'Peso': 'no label', 'Califica_1': 'no label', 'Criterio__': 'no label', 'Peso_1': 'no label', 'Califica_2': 'no label', 'Criterio_1': 'no label', 'Peso_12': 'no label', 'Califica_3': 'no label', 'Criterio': 'no label', 'Peso_12_13': 'no label', 'Califica_4': 'no label', 'Criterio_2': 'no label', 'SUMA': 'no label', 'NORTE_MBOG': 'no label', 'ESTE_MBOG': 'no label', 'LONGITUD': 'no label', 'LATITUD': 'no label', });
lyr_4CTE_CRITICIDAD_GEAM_7.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});